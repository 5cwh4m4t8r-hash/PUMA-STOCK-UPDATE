from __future__ import annotations
from datetime import datetime
from statistics import mean
from .models import StrategySettings, SignalResult, Position


def _num(v):
    try:
        return abs(float(str(v).replace(",", "").strip()))
    except Exception:
        return 0.0


def sma(values, period):
    if len(values) < period or period <= 0:
        return None
    return sum(values[-period:]) / period


def ema_last(values, period):
    """PUMA 전 전략의 기본 이평은 EMA(지수이동평균)로 통일."""
    if len(values) < period or period <= 0:
        return None
    prev = sum(values[:period]) / period
    k = 2.0 / (period + 1.0)
    for v in values[period:]:
        prev = v * k + prev * (1.0 - k)
    return prev


def rsi(values, period=14):
    if len(values) < period + 1:
        return None
    gains, losses = [], []
    for a, b in zip(values[-period-1:-1], values[-period:]):
        d = b - a
        gains.append(max(d, 0))
        losses.append(max(-d, 0))
    avg_gain = mean(gains)
    avg_loss = mean(losses)
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))


def in_scan_window(settings: StrategySettings, now=None):
    now = now or datetime.now()
    hm = now.strftime("%H:%M")
    return settings.scan_start <= hm <= settings.scan_end


def evaluate_buy(candles, settings: StrategySettings) -> SignalResult:
    if len(candles) < max(settings.ma_slow, settings.breakout_lookback, 20) + 2:
        return SignalResult(False, "데이터 부족")

    candles = list(reversed(candles))  # API 최신순 -> 시간순
    closes = [_num(c.get("cur_prc")) for c in candles]
    highs = [_num(c.get("high_pric")) for c in candles]
    volumes = [_num(c.get("trde_qty")) for c in candles]
    current = closes[-1]
    prev_close = closes[-2] or current
    change_pct = (current / prev_close - 1) * 100 if prev_close else 0.0

    # 장중 등락률이 없을 경우 최근 봉 대비 변화율을 사용한다.
    if not (settings.min_change_pct <= change_pct <= settings.max_change_pct):
        return SignalResult(False, f"등락률 {change_pct:.2f}%", current_price=current, change_pct=change_pct)

    avg_vol = mean(volumes[-11:-1]) if len(volumes) >= 11 else mean(volumes[:-1])
    vol_ratio = (volumes[-1] / avg_vol) if avg_vol else 0.0
    if vol_ratio < settings.volume_ratio_min:
        return SignalResult(False, f"거래량 {vol_ratio:.2f}배", current_price=current, change_pct=change_pct, volume_ratio=vol_ratio)

    score = 1
    if settings.use_ma_stack:
        fast = ema_last(closes, settings.ma_fast)
        mid = ema_last(closes, settings.ma_mid)
        slow = ema_last(closes, settings.ma_slow)
        if None in (fast, mid, slow) or not (current >= fast > mid > slow):
            return SignalResult(False, "이평 정배열 불충족", score, current, change_pct, vol_ratio)
        score += 1

    if settings.use_breakout:
        prior_high = max(highs[-settings.breakout_lookback-1:-1])
        if current <= prior_high:
            return SignalResult(False, "돌파 불충족", score, current, change_pct, vol_ratio)
        score += 1

    cur_rsi = rsi(closes)
    if settings.use_rsi:
        if cur_rsi is None or not (settings.rsi_min <= cur_rsi <= settings.rsi_max):
            return SignalResult(False, f"RSI {cur_rsi if cur_rsi is not None else '-'}", score, current, change_pct, vol_ratio, cur_rsi)
        score += 1

    return SignalResult(True, "매수조건 충족", score, current, change_pct, vol_ratio, cur_rsi)


def evaluate_sell(position: Position, current_price: float, settings: StrategySettings, now=None):
    pnl = position.pnl_pct(current_price)
    position.highest_price = max(position.highest_price, current_price)

    if pnl >= settings.take_profit_pct:
        return True, f"익절 {pnl:.2f}%"
    if pnl <= settings.stop_loss_pct:
        return True, f"손절 {pnl:.2f}%"

    if settings.trailing_enabled and pnl >= settings.trailing_start_pct:
        drop_from_high = (current_price / position.highest_price - 1) * 100 if position.highest_price else 0
        if drop_from_high <= -abs(settings.trailing_gap_pct):
            return True, f"트레일링 {drop_from_high:.2f}%"

    now = now or datetime.now()
    if settings.force_exit_enabled and now.strftime("%H:%M") >= settings.force_exit_time:
        return True, "장 종료 전 청산"
    return False, "보유"
