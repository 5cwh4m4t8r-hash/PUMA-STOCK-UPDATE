from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from math import sqrt
from statistics import mean
from typing import Dict, List

from .swing import normalize_candles
from .danta import market_open_volume_ratio


@dataclass
class GabojaSignal:
    passed: bool
    entry_kind: str = ""
    reason: str = ""
    current_price: float = 0.0
    basis_open: float = 0.0
    young1_high: float = 0.0
    pullback_low: float = 0.0
    day_volume_ratio: float = 0.0
    details: Dict[str, object] = field(default_factory=dict)


def _date_key(raw) -> str:
    return "".join(ch for ch in str(raw or "") if ch.isdigit())[:8]


def _hm(raw) -> str:
    s = "".join(ch for ch in str(raw or "") if ch.isdigit())
    if len(s) >= 12:
        return s[8:10] + ":" + s[10:12]
    return ""


def _bar_elapsed_seconds(raw, now: datetime, timeframe_min: int = 5) -> float:
    """Elapsed seconds inside the live candle bucket.

    Historical/completed bars return a full timeframe. The active bar uses only
    elapsed wall-clock time so raw cumulative volume is never compared directly
    with a completed Young bar.
    """
    full = float(max(1, int(timeframe_min or 5)) * 60)
    digits = "".join(ch for ch in str(raw or "") if ch.isdigit())
    if len(digits) < 12:
        return full
    try:
        stamp = datetime.strptime(digits[:12], "%Y%m%d%H%M")
    except Exception:
        return full
    if stamp.date() != now.date():
        return full
    delta = (now - stamp).total_seconds()
    if delta < 0 or delta >= full:
        return full
    return max(0.0, float(delta))


def _volume_pace(volume: float, elapsed_seconds: float) -> float:
    sec = max(1.0, float(elapsed_seconds or 0.0))
    return max(0.0, float(volume or 0.0)) / sec


def _premarket_snapshot(
    candles_raw: List[dict],
    day: str,
    *,
    start: str = "08:00",
    end: str = "08:50",
) -> dict:
    """Summarize today's NXT premarket bars without turning them into buy signals."""
    candles = normalize_candles(candles_raw or [])
    rows = [
        x for x in candles
        if _date_key(x.get("date")) == str(day)
        and start <= _hm(x.get("date")) < end
    ]
    if not rows:
        return {
            "premarket_available": False,
            "premarket_bars": 0,
            "premarket_open": 0.0,
            "premarket_close": 0.0,
            "premarket_high": 0.0,
            "premarket_low": 0.0,
            "premarket_volume": 0.0,
            "premarket_change_pct": 0.0,
            "premarket_high_retention_pct": 0.0,
        }

    op = float(rows[0]["open"])
    cl = float(rows[-1]["close"])
    hi = max(float(x["high"]) for x in rows)
    lo = min(float(x["low"]) for x in rows)
    vol = sum(float(x["volume"]) for x in rows)
    return {
        "premarket_available": True,
        "premarket_bars": len(rows),
        "premarket_open": op,
        "premarket_close": cl,
        "premarket_high": hi,
        "premarket_low": lo,
        "premarket_volume": vol,
        "premarket_change_pct": ((cl / op - 1.0) * 100.0) if op > 0 else 0.0,
        "premarket_high_retention_pct": ((cl / hi) * 100.0) if hi > 0 else 0.0,
    }


def _eavg(values: List[float], period: int) -> List[float]:
    if not values:
        return []
    alpha = 2.0 / (float(period) + 1.0)
    out = [float(values[0])]
    for value in values[1:]:
        out.append(float(value) * alpha + out[-1] * (1.0 - alpha))
    return out


def _bb_upper(values: List[float], period: int = 40, dev: float = 2.2) -> List[float | None]:
    out: List[float | None] = [None] * len(values)
    if period <= 1:
        return out
    for i in range(period - 1, len(values)):
        xs = [float(x) for x in values[i - period + 1:i + 1]]
        m = sum(xs) / period
        sd = sqrt(sum((x - m) ** 2 for x in xs) / period)
        out[i] = m + float(dev) * sd
    return out


def _candidate_filter(
    daily_rows: List[dict],
    live_bar: dict | None = None,
    *,
    session_bars: int = 1,
    morning_volume_ratio: float = 0.0,
    min_score: int = 3,
) -> tuple[bool, dict]:
    """PUMA 2차 후보 선별.

    영웅문 검색기가 1차 후보를 공급한 뒤 PUMA가 장중 힘을 재검증한다.
    장초 누적 거래량은 최근 5일 동일 시간대 평균 대비 300% 이상이어야 한다.

    점수(4개 중 3개 이상) + 장초 거래량 300% 필수:
      1) 현재가가 시가 이상
      2) 장중 거래량/거래대금 진행속도가 전일 평균 진행속도 대비 강함
      3) 전일고 또는 최근 5일 고점을 공격 중
      4) EMA112/224/448 또는 BB40/2.2 저항을 당일 공격/돌파
    """
    daily = normalize_candles(daily_rows or [])
    if live_bar:
        live_day = _date_key(live_bar.get("date"))
        if daily and _date_key(daily[-1].get("date")) == live_day:
            daily[-1] = dict(live_bar)
        elif not daily or _date_key(daily[-1].get("date")) < live_day:
            daily.append(dict(live_bar))
    if len(daily) < 6:
        return False, {"reason": "일봉 6봉 미만", "puma_score": 0}

    cur = daily[-1]
    prev = daily[-2]
    prev5 = daily[-6:-1]
    cur_open = float(cur["open"])
    cur_high = float(cur["high"])
    cur_close = float(cur["close"])
    cur_volume = float(cur["volume"])

    prev_high = float(prev["high"])
    prev5_high = max(float(x["high"]) for x in prev5)
    gap_ok = cur_open > prev5_high

    prev_vol = float(prev["volume"])
    day_volume_ratio = cur_volume / prev_vol if prev_vol > 0 else 0.0

    # 장중 누적 거래량을 '전일 하루 전체'와 직접 비교하지 않고,
    # 현재까지 경과한 5분봉 비율로 환산하여 진행속도를 비교한다.
    bars = max(1, int(session_bars or 1))
    elapsed_fraction = min(1.0, max(5.0 / 390.0, (bars * 5.0) / 390.0))
    expected_vol = prev_vol * elapsed_fraction
    volume_pace = cur_volume / expected_vol if expected_vol > 0 else 0.0

    prev_turnover = max(0.0, float(prev["close"]) * prev_vol)
    cur_turnover = max(0.0, cur_close * cur_volume)
    expected_turnover = prev_turnover * elapsed_fraction
    turnover_pace = cur_turnover / expected_turnover if expected_turnover > 0 else 0.0
    flow_pace = max(volume_pace, turnover_pace)
    morning_volume_ratio = float(morning_volume_ratio or 0.0)
    volume_burst_ok = morning_volume_ratio >= 3.0
    flow_ok = volume_burst_ok

    price_strength = cur_close >= cur_open

    # '돌파 완료'만 보지 않고 실제로 최근 고점을 공격하는 종목까지 후보로 인정한다.
    prev_high_attack = cur_high >= prev_high * 0.995 if prev_high > 0 else False
    prev5_attack = cur_high >= prev5_high * 0.99 if prev5_high > 0 else False
    high_attack = bool(prev_high_attack or prev5_attack)

    closes = [float(x["close"]) for x in daily]
    long_hits = []
    long_levels = {}
    for period in (112, 224, 448):
        arr = _eavg(closes, period)
        level = float(arr[-1])
        prev_level = float(arr[-2]) if len(arr) >= 2 else level
        long_levels[period] = level
        attacked = (
            cur_high >= level
            and cur_close >= level * 0.995
            and (cur_open <= level or float(prev["close"]) <= prev_level)
        )
        if attacked:
            long_hits.append(period)

    bb = _bb_upper(closes, 40, 2.2)
    bb_ok = False
    bb_level = None
    if len(bb) >= 2 and bb[-1] is not None:
        bb_level = float(bb[-1])
        prev_bb = float(bb[-2]) if bb[-2] is not None else bb_level
        bb_ok = (
            cur_high >= bb_level
            and cur_close >= bb_level * 0.995
            and (cur_open <= bb_level or float(prev["close"]) <= prev_bb)
        )

    resistance_ok = bool(long_hits or bb_ok)

    score = sum((
        1 if price_strength else 0,
        1 if flow_ok else 0,
        1 if high_attack else 0,
        1 if resistance_ok else 0,
    ))
    ok = bool(volume_burst_ok and score >= max(1, int(min_score)))

    reasons = [
        f"시가위 {'O' if price_strength else 'X'}",
        f"장초거래량 {morning_volume_ratio:.2f}x {'O' if volume_burst_ok else 'X'}",
        f"고점공격 {'O' if high_attack else 'X'}",
        (
            "장기저항 " + (
                "EMA" + ",".join(map(str, long_hits))
                if long_hits else ("BB40/2.2" if bb_ok else "X")
            )
        ),
    ]
    return ok, {
        "reason": " · ".join(reasons) + f" · PUMA {score}/4",
        "basis_open": cur_open,
        "prev_high": prev_high,
        "prev5_high": prev5_high,
        "day_volume_ratio": day_volume_ratio,
        "volume_pace": volume_pace,
        "turnover_pace": turnover_pace,
        "flow_pace": flow_pace,
        "morning_volume_ratio": morning_volume_ratio,
        "morning_volume_300_ok": volume_burst_ok,
        "gap_ok": gap_ok,  # 정보만 기록. 필수조건 아님.
        "price_strength": price_strength,
        "flow_ok": flow_ok,
        "high_attack": high_attack,
        "prev_high_attack": prev_high_attack,
        "prev5_attack": prev5_attack,
        "long_ma_hits": long_hits,
        "long_ma_levels": long_levels,
        "bb40_22_breakout": bb_ok,
        "bb40_22_level": bb_level,
        "resistance_ok": resistance_ok,
        "puma_score": score,
        "date": _date_key(cur.get("date")),
    }

def evaluate_gaboja(
    minute_rows: List[dict],
    daily_rows: List[dict],
    *,
    now: datetime | None = None,
    scan_start: str = "08:00",
    trade_start: str = "08:00",
    scan_end: str = "10:00",
    apply_secondary_filter: bool = True,
    secondary_min_score: int = 3,
    cha_max_ratio: float = 0.65,
    cha_volume_pace_ratio: float = 1.00,
    cha_min_live_seconds: int = 20,
) -> GabojaSignal:
    """가보자 단타 자동진입.

    1) NXT 프리마켓 08:00부터 후보 검색과 실제 자동매매를 함께 시작한다.
       09:00 이후에는 08시부터 이어진 NXT 흐름과 KRX 신규 후보를 같은 PUMA 기준으로 비교한다.
    2) 1영은 장대양봉 한 봉에 고정하지 않는다. 특히 장 시작 첫 5분봉은 음봉이어도
       거래량/변동폭이 살아 있으면 1영 구조의 시작봉으로 인정한다.
    3) 차는 기존 65% 깊은 되돌림 + 거래량 진행속도 둔화 규칙을 그대로 쓴다.
       진행 중인 차가 조건을 충족하는 순간 바로 매수한다.
    4) 영차영차의 구조는 거래량 모양이 아니라 가격 구조다:
       1영(상승봉 또는 상승 언덕) -> 차(눌림) -> 2영(1영 전고 몸통돌파).
       차 자체는 거래량과 무관하게 추적하며, 거래량 둔화는 차 직접매수의 보조/안전 조건으로만 쓴다.
       차에서 직접 못 샀거나 거래량 조건이 안 맞아도 구조를 버리지 않고 계속 추적하다가,
       이후 양봉 몸통이 1영 전고를 실제 돌파하면 2영 진입을 허용한다. 윗꼬리 돌파는 제외한다.
       차 진입의 최초 손절은 기준봉 시가, 2영 진입은 확인된 눌림 저점이다.
    """
    candles = normalize_candles(minute_rows or [])
    if not candles:
        return GabojaSignal(False, reason="5분봉 데이터 없음")

    now = now or datetime.now()
    hm = now.strftime("%H:%M")
    latest_day = _date_key(candles[-1].get("date"))
    today_key = now.strftime("%Y%m%d")
    latest_price = float(candles[-1]["close"])
    premarket = _premarket_snapshot(candles, today_key)

    # trade_start 이전에는 신규진입을 막는다. v2.9.59 기본 trade_start는
    # 08:00이므로 NXT 프리마켓도 실제 가보자 진입 세션에 포함된다.
    if hm < trade_start:
        if hm < scan_start:
            reason = f"가보자 검색 시작 전 · {scan_start} 대기"
        elif premarket.get("premarket_available"):
            reason = f"가보자 검색 중 · 실제 자동매수는 {trade_start}부터"
        else:
            reason = f"가보자 후보 탐색 중 · 실제 자동매수는 {trade_start}부터"
        return GabojaSignal(
            False,
            reason=reason,
            current_price=latest_price,
            details={**premarket, "time_ok": False, "trade_start": trade_start},
        )

    # 장 시작 직후 API가 아직 전일 마지막 봉을 반환할 수 있으므로 stale 재진입을 막는다.
    if latest_day != today_key:
        return GabojaSignal(
            False,
            reason=f"당일 5분봉 대기 · 최신 데이터 {latest_day or '없음'}",
            current_price=latest_price,
            details={**premarket, "time_ok": False, "trade_start": trade_start},
        )

    day = latest_day
    session = [
        x for x in candles
        if _date_key(x.get("date")) == day
        and (_hm(x.get("date")) == "" or _hm(x.get("date")) >= trade_start)
    ]
    if not session:
        return GabojaSignal(False, reason="장중 5분봉 데이터 없음", current_price=latest_price)

    # 일봉 과거값은 캐시하고, 오늘 OHLCV는 최신 5분봉들로 합성한다.
    # PUMA는 갭 여부가 아니라 장중 가격 힘/거래속도/고점공격/저항공격을 재검증한다.
    live_bar = {
        "date": day,
        "open": float(session[0]["open"]),
        "high": max(float(x["high"]) for x in session),
        "low": min(float(x["low"]) for x in session),
        "close": float(session[-1]["close"]),
        "volume": sum(float(x["volume"]) for x in session),
    }
    morning = market_open_volume_ratio(candles, 5, session_start=trade_start)
    morning_ratio = float(morning.get("ratio", 0.0) or 0.0)
    candidate_ok, d = _candidate_filter(
        daily_rows,
        live_bar,
        session_bars=len(session),
        morning_volume_ratio=morning_ratio,
        min_score=secondary_min_score,
    )
    basis_open = float(d.get("basis_open", live_bar["open"]) or live_bar["open"])
    # GabojaSignal의 거래량 비율도 이제 장초 동일시간대 5일 평균 대비 비율을 사용한다.
    day_ratio = float(d.get("morning_volume_ratio", 0.0) or 0.0)
    if apply_secondary_filter and not candidate_ok:
        return GabojaSignal(
            False,
            reason=f"PUMA 2차 선별 대기 · {d.get('reason','-')}",
            current_price=float(session[-1]["close"]),
            basis_open=basis_open,
            day_volume_ratio=day_ratio,
            details={**d, **premarket, "trade_start": trade_start},
        )
    if len(session) < 2:
        return GabojaSignal(
            False,
            reason="가보자 5분봉 구조 형성 대기",
            current_price=float(candles[-1]["close"]),
            basis_open=basis_open,
            day_volume_ratio=day_ratio,
            details={**d, **premarket, "trade_start": trade_start},
        )

    entry_window_start = max(str(scan_start), str(trade_start))
    time_ok = entry_window_start <= hm <= scan_end
    current = session[-1]
    current_price = float(current["close"])

    # 실시간 차 영역:
    #   B = 구조 바닥, H = 1영 전고, R = H-B
    #   기본값 B < 현재가 <= B + R*0.65  (1영 상승폭에서 35% 이상 되돌림)
    # 실제 상승 뒤 첫 눌림을 차로 잡되, 단순 고점 횡보는 제외한다.
    cha_ratio = min(0.95, max(0.05, float(cha_max_ratio or 0.65)))
    cha_pace_ratio = min(2.0, max(0.10, float(cha_volume_pace_ratio or 1.00)))
    cha_live_min_sec = max(0, min(120, int(cha_min_live_seconds or 0)))
    latest_index = len(session) - 1

    # 1영은 첫 5분봉부터 볼 수 있다. 첫 봉은 음봉이어도 후보가 이미
    # 장초 거래량/PUMA 힘 필터를 통과했다면 구조의 시작봉으로 인정한다.
    # 영차영차 구조 자체는 가격으로 판정한다. 봉 단위 거래량은 1영/차/2영 구조를
    # 끊는 필수조건이 아니며, 차 직접매수 품질과 후보 강도 판단에만 보조로 사용한다.
    quiet_cha_pairs = []
    structural_watches = []
    second_young_setups = []

    for i in range(0, len(session) - 1):
        bar = session[i]
        bar_open = float(bar["open"])
        bar_high = float(bar["high"])
        bar_low = float(bar["low"])
        bar_close = float(bar["close"])
        bar_range = max(0.0, bar_high - bar_low)
        body_top = max(bar_open, bar_close)
        body_size = abs(bar_close - bar_open)
        upper_wick = max(0.0, bar_high - body_top)
        close_retention = ((bar_close - bar_low) / bar_range) if bar_range > 0 else 0.0

        # 첫 봉은 음봉이어도 1영이 될 수 있지만, RFHIC처럼 고가만 순간적으로
        # 크게 찌르고 몸통이 아래에 남은 '윗꼬리 급등-실패' 봉은 1영으로 인정하지 않는다.
        opening_young = (
            i == 0
            and float(bar["volume"]) > 0
            and bar_range > 0
            and (
                # 사용자가 지정한 기존 규칙: 첫 봉 음봉도 1영 가능.
                bar_close < bar_open
                or (
                    # 양봉 첫 봉은 RFHIC형 윗꼬리 급등-실패를 제외한다.
                    close_retention >= 0.50
                    and upper_wick <= max(body_size * 1.50, bar_range * 0.30)
                )
            )
        )

        if opening_young:
            young_start = 0
            young_high = bar_high
            young_volume = float(bar["volume"])
            young_volume_total = float(bar["volume"])
            young_bar_count = 1
            young_kind = "opening_bearish" if bar_close < bar_open else "opening"
            # 첫 봉 음봉은 당일 시가 아래에서 끝날 수 있으므로 구조 바닥은 첫 봉 저가로 둔다.
            structural_floor = min(basis_open, bar_low)
        else:
            prior = session[max(0, i - 3):i]
            if not prior:
                continue

            prior_high = max(float(x["high"]) for x in prior)
            prior_vol = mean(float(x["volume"]) for x in prior)
            single_volume_expansion = float(bar["volume"]) >= prior_vol if prior_vol > 0 else True

            # 단봉 1영: 가격이 실제로 상승하며 직전 고점을 공격했는지만 본다.
            # 후보 자체의 거래량 강도는 앞단 PUMA 2차선별에서 이미 검증하므로
            # 이 봉의 거래량이 직전 봉들보다 반드시 커야 한다고 다시 강제하지 않는다.
            single_impulse = (
                float(bar["close"]) > float(bar["open"])
                and max(float(bar["open"]), float(bar["close"])) > prior_high
            )

            # 언덕형 1영: 최근 최대 7봉 안에서 저점부터 이어진 상승 언덕 전체를 인정한다.
            lookback_start = max(0, i - 6)
            lookback = session[lookback_start:i + 1]
            rel_start = min(
                range(len(lookback)),
                key=lambda k: float(lookback[k]["low"]),
            )
            young_start = lookback_start + rel_start
            hill = session[young_start:i + 1]
            bullish = sum(1 for x in hill if float(x["close"]) >= float(x["open"]))
            progress = sum(
                1 for k in range(1, len(hill))
                if float(hill[k]["close"]) >= float(hill[k - 1]["close"])
            )
            hill_high = max(float(x["high"]) for x in hill)
            hill_open = float(hill[0]["open"])
            before_hill = session[max(0, young_start - 3):young_start]
            before_high = max((float(x["high"]) for x in before_hill), default=basis_open)
            hill_shape = (
                len(hill) >= 2
                and float(bar["high"]) >= hill_high
                and float(bar["close"]) > hill_open
                and hill_high > max(basis_open, before_high)
                and bullish >= max(2, (len(hill) + 1) // 2)
                and progress >= max(1, (len(hill) - 1) // 2)
            )

            # 가격 구조가 둘 다 성립할 때만 거래량을 '분류 보조'로 쓴다.
            # 현재 봉 거래량이 직전 평균 이상이면 단봉 추진력(single)으로 보고,
            # 그렇지 않으면 여러 봉 누적 상승(hill)로 보존한다.
            # 중요한 점: 거래량 부족 때문에 1영 자체를 탈락시키지는 않는다.
            if single_impulse and (not hill_shape or single_volume_expansion):
                young_start = i
                young_high = float(bar["high"])
                young_volume = float(bar["volume"])
                young_volume_total = float(bar["volume"])
                young_bar_count = 1
                young_kind = "single"
            elif hill_shape:
                young_high = hill_high
                young_volume = max(float(x["volume"]) for x in hill)
                young_volume_total = sum(float(x["volume"]) for x in hill)
                young_bar_count = max(1, len(hill))
                young_kind = "hill"
            elif single_impulse:
                young_start = i
                young_high = float(bar["high"])
                young_volume = float(bar["volume"])
                young_volume_total = float(bar["volume"])
                young_bar_count = 1
                young_kind = "single"
            else:
                continue
            structural_floor = basis_open

        rise = young_high - structural_floor
        if rise <= 0:
            continue

        cha_ceiling = structural_floor + rise * cha_ratio
        young_pace = _volume_pace(
            young_volume_total,
            float(young_bar_count * 5 * 60),
        )

        # 차(눌림)는 가격 구조로 먼저 기록한다.
        # 35% 이상 실제 눌림이 확인되면 거래량이 크든 작든 차/2영 구조를 계속 추적한다.
        # v2.9.73 실전 수정: 거래량 둔화는 보조정보일 뿐 차 직접매수의 필수조건이 아니다.
        structural_pullback_idx = -1
        structural_pullback_low = 0.0
        structural_pullback_depth = 0.0
        structural_pullback_pace = 0.0
        structural_pullback_elapsed = 0.0
        structure_invalid = False
        quiet_cha_recorded = False

        for j in range(i + 1, len(session)):
            pb = session[j]
            pb_low = float(pb["low"])
            pb_close = float(pb["close"])

            # 1영 구조 바닥 자체가 깨지면 이 영차영차 구조는 폐기한다.
            if pb_low <= structural_floor or pb_close <= structural_floor:
                structure_invalid = True
                break

            prev_close = float(session[j - 1]["close"]) if j > 0 else pb_close
            pullback_shape = (
                young_kind == "opening_bearish"
                or pb_close < prev_close
                or float(pb["close"]) < float(pb["open"])
                or pb_low < float(session[j - 1]["low"])
            )
            deep_zone = structural_floor < pb_close <= cha_ceiling and pullback_shape
            is_live_bar = j == latest_index
            if is_live_bar:
                elapsed = _bar_elapsed_seconds(pb.get("date"), now, 5)
                live_ready = elapsed >= float(cha_live_min_sec)
            else:
                elapsed = 5.0 * 60.0
                live_ready = True

            pb_pace = _volume_pace(float(pb["volume"]), elapsed if elapsed > 0 else 1.0)
            lower_volume_pace = young_pace > 0 and pb_pace <= young_pace * cha_pace_ratio

            if deep_zone and live_ready:
                depth_pct = ((young_high - pb_close) / rise) * 100.0

                if structural_pullback_idx < 0:
                    structural_pullback_idx = j
                    structural_pullback_low = pb_low
                    structural_pullback_depth = depth_pct
                    structural_pullback_pace = pb_pace
                    structural_pullback_elapsed = elapsed
                else:
                    structural_pullback_low = min(structural_pullback_low, pb_low)
                    structural_pullback_depth = max(structural_pullback_depth, depth_pct)
                    structural_pullback_pace = pb_pace
                    structural_pullback_elapsed = elapsed

                # 차 직접매수는 가격 구조가 기준이다.
                # 거래량 진행속도는 기록만 하고, 빠르다는 이유로 사용자가 지정한 차를 버리지 않는다.
                if not quiet_cha_recorded:
                    quiet_cha_pairs.append((
                        young_start, i, j, young_high, pb_low,
                        cha_ceiling, young_volume, young_kind, depth_pct,
                        young_pace, pb_pace, elapsed, lower_volume_pace,
                        structural_floor,
                    ))
                    quiet_cha_recorded = True

            # 차를 찍고 회복하는 동안 더 낮은 저점이 생기면 실제 눌림 저점으로 갱신한다.
            elif structural_pullback_idx >= 0:
                structural_pullback_low = min(structural_pullback_low, pb_low)

        if structural_pullback_idx < 0 or structure_invalid:
            continue

        structural_watches.append((
            young_start, i, structural_pullback_idx, young_high, structural_pullback_low,
            cha_ceiling, young_volume, young_kind, structural_pullback_depth,
            young_pace, structural_pullback_pace, structural_pullback_elapsed,
            structural_floor,
        ))

        # 2영: 차 이후 몇 봉을 천천히 회복했든 상관없이 현재 양봉 몸통이
        # 1영 전고를 실제로 가로질러 돌파하면 진입 후보. 거래량은 필수조건이 아니다.
        if latest_index > structural_pullback_idx:
            current_bar = session[latest_index]
            current_body_low = min(float(current_bar["open"]), float(current_bar["close"]))
            current_body_high = max(float(current_bar["open"]), float(current_bar["close"]))
            second_young_body_break = bool(
                float(current_bar["close"]) > float(current_bar["open"])
                and current_body_low <= young_high < current_body_high
                and float(current_bar["low"]) > structural_floor
            )
            if second_young_body_break:
                second_young_setups.append((
                    young_start, i, structural_pullback_idx, young_high, structural_pullback_low,
                    cha_ceiling, young_volume, young_kind, structural_pullback_depth,
                    young_pace, structural_pullback_pace, structural_pullback_elapsed,
                    structural_floor,
                ))

    latest = len(session) - 1

    # 1차 진입: 현재봉 자체가 가격 구조상 차면 즉시 매수. 거래량은 보조정보다.
    current_cha_pairs = [x for x in quiet_cha_pairs if x[2] == latest]
    if current_cha_pairs:
        (
            young_start, i, j, young1_high, pullback_low, cha_ceiling,
            young_volume, young_kind, cha_depth_pct, young_pace,
            pullback_pace, pullback_elapsed_sec, lower_volume_pace,
            structural_floor,
        ) = max(current_cha_pairs, key=lambda x: x[1])
        pb = session[j]
        passed = bool(time_ok)
        opening_note = " · 첫봉 음봉 1영 인정" if young_kind == "opening_bearish" else ""
        reason = (
            f"가보자 1영→차 매수{opening_note} · 35% 이상 실제 눌림 "
            f"({current_price:,.0f} ≤ {cha_ceiling:,.0f}) · "
            f"거래량속도 {pullback_pace:.2f}/s (보조) · "
            f"기준봉 시가 {basis_open:,.0f} 이탈 손절"
            if passed else
            f"가보자 1영→차 확인 · 검색시간 외({scan_start}~{scan_end})"
        )
        return GabojaSignal(
            passed=passed,
            entry_kind="PULLBACK" if passed else "",
            reason=reason,
            current_price=current_price,
            basis_open=basis_open,
            young1_high=young1_high,
            pullback_low=pullback_low,
            day_volume_ratio=day_ratio,
            details={
                **d,
                **premarket,
                "time_ok": time_ok,
                "trade_start": trade_start,
                "young1_index": i,
                "young_start_index": young_start,
                "young_end_index": i,
                "young_kind": young_kind,
                "opening_bearish_young": young_kind == "opening_bearish",
                "structural_floor": structural_floor,
                "pullback_index": j,
                "young2_index": -1,
                "young2_price": 0.0,
                "young1_high": young1_high,
                "pullback_low": pullback_low,
                "cha_ceiling": cha_ceiling,
                "cha_max_ratio": cha_ratio,
                "cha_depth_pct": cha_depth_pct,
                "early_cha": True,
                "cha_ready": True,
                "cha_volume_pace_ratio": cha_pace_ratio,
                "cha_min_live_seconds": cha_live_min_sec,
                "pullback_elapsed_sec": pullback_elapsed_sec,
                "pullback_volume_pace": pullback_pace,
                "young_volume_pace": young_pace,
                "lower_volume_pace": lower_volume_pace,
                "pullback_volume": float(pb["volume"]),
                "young1_volume": young_volume,
                "body_rebreak": False,
                "second_young": False,
                "volume_required_for_structure": False,
            },
        )

    # 2차 진입: 차 직접매수를 못 했더라도 가격 구조를 계속 추적한다.
    # 거래량이 많든 적든, 천천히 회복했든 빠르게 회복했든 전고 몸통돌파만 확인되면 2영.
    if second_young_setups:
        (
            young_start, i, j, young1_high, pullback_low, cha_ceiling,
            young_volume, young_kind, cha_depth_pct, young_pace,
            pullback_pace, pullback_elapsed_sec, structural_floor,
        ) = min(second_young_setups, key=lambda x: (x[2], -x[1]))
        passed = bool(time_ok)
        opening_note = " · 첫봉 음봉 1영 인정" if young_kind == "opening_bearish" else ""
        reason = (
            f"가보자 1영→차→2영 전고 몸통돌파 매수{opening_note} · "
            f"전고 {young1_high:,.0f} 몸통돌파 확인 · "
            f"눌림저점 {pullback_low:,.0f} 이탈 손절"
            if passed else
            f"1영→차→2영 전고 몸통돌파 확인 · 검색시간 외({scan_start}~{scan_end})"
        )
        return GabojaSignal(
            passed=passed,
            entry_kind="YOUNG2" if passed else "",
            reason=reason,
            current_price=current_price,
            basis_open=basis_open,
            young1_high=young1_high,
            pullback_low=pullback_low,
            day_volume_ratio=day_ratio,
            details={
                **d,
                **premarket,
                "time_ok": time_ok,
                "trade_start": trade_start,
                "young1_index": i,
                "young_start_index": young_start,
                "young_end_index": i,
                "young_kind": young_kind,
                "opening_bearish_young": young_kind == "opening_bearish",
                "structural_floor": structural_floor,
                "pullback_index": j,
                "young2_index": latest,
                "young2_price": current_price,
                "young1_high": young1_high,
                "pullback_low": pullback_low,
                "cha_ceiling": cha_ceiling,
                "cha_max_ratio": cha_ratio,
                "cha_depth_pct": cha_depth_pct,
                "early_cha": False,
                "cha_ready": True,
                "cha_volume_pace_ratio": cha_pace_ratio,
                "cha_min_live_seconds": cha_live_min_sec,
                "pullback_elapsed_sec": pullback_elapsed_sec,
                "pullback_volume_pace": pullback_pace,
                "young_volume_pace": young_pace,
                "lower_volume_pace": (
                    young_pace > 0
                    and pullback_pace <= young_pace * cha_pace_ratio
                ),
                "pullback_volume": float(session[j]["volume"]),
                "young1_volume": young_volume,
                "body_rebreak": True,
                "second_young": True,
                "volume_required_for_structure": False,
            },
        )

    if structural_watches:
        watch = min(structural_watches, key=lambda x: (x[2], -x[1]))
        return GabojaSignal(
            False,
            reason="가보자 1영→차 확인 · 2영 전고 몸통돌파 감시 중",
            current_price=current_price,
            basis_open=basis_open,
            young1_high=float(watch[3]),
            pullback_low=float(watch[4]),
            day_volume_ratio=day_ratio,
            details={
                **d,
                **premarket,
                "time_ok": time_ok,
                "trade_start": trade_start,
                "cha_max_ratio": cha_ratio,
                "cha_volume_pace_ratio": cha_pace_ratio,
                "cha_min_live_seconds": cha_live_min_sec,
                "structural_pullback": True,
                "second_young": False,
                "volume_required_for_structure": False,
            },
        )

    return GabojaSignal(
        False,
        reason="1영 이후 35% 이상 차(눌림) 형성 대기",
        current_price=current_price,
        basis_open=basis_open,
        day_volume_ratio=day_ratio,
        details={
            **d,
            **premarket,
            "time_ok": time_ok,
            "trade_start": trade_start,
            "cha_max_ratio": cha_ratio,
            "cha_volume_pace_ratio": cha_pace_ratio,
            "cha_min_live_seconds": cha_live_min_sec,
            "structural_pullback": False,
            "second_young": False,
            "volume_required_for_structure": False,
        },
    )
