from __future__ import annotations

from datetime import datetime
from bisect import bisect_left, bisect_right

from PySide6.QtCore import Qt, QRectF, QPointF, Signal
from PySide6.QtGui import QColor, QPainter, QPen, QFont, QPolygonF
from PySide6.QtWidgets import QWidget


class SwingChart(QWidget):
    """PUMA 공용 캔들 차트.

    v1.4: 마우스 휠 확대/축소, 좌우 드래그 과거 탐색, 선택 분석구간 강조,
    일봉/분봉 공용 표시를 지원한다.
    """

    viewportChanged = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.series = None
        self.analysis = None
        self.title = ''
        self.view_bars = 130
        self.view_end: int | None = None  # exclusive index
        self.analysis_range: tuple[int, int] | None = None
        self._drag_x = None
        self._drag_end = None
        self.setMinimumHeight(430)
        self.setMouseTracking(True)

    def set_data(self, analysis, series, title: str = '', preserve_view: bool = False):
        old_end = self.view_end
        old_candles = (self.series or {}).get('candles', [])
        was_latest = old_end is None or old_end >= len(old_candles)
        anchor = str(old_candles[min(old_end, len(old_candles))-1].get('date', '')) if old_candles and old_end else ''
        range_dates = None
        if self.analysis_range and old_candles:
            a, b = self.analysis_range
            if 0 <= a <= b < len(old_candles):
                range_dates = (str(old_candles[a].get('date', '')), str(old_candles[b].get('date', '')))
        self.analysis = analysis
        self.series = series
        self.title = title or self.title
        n = len(series.get('candles', [])) if series else 0
        new_candles = (series or {}).get('candles', [])
        date_key = lambda c: str(c.get('date', ''))
        if not preserve_view or was_latest:
            self.view_end = n
        else:
            # Older pages are prepended. Preserve the visible date, not its old index.
            self.view_end = min(n, max(1, bisect_right(new_candles, anchor, key=date_key)))
        if preserve_view and range_dates and n:
            a = bisect_left(new_candles, range_dates[0], key=date_key)
            b = bisect_right(new_candles, range_dates[1], key=date_key) - 1
            self.analysis_range = (a, b) if a <= b < n else None
        self.view_bars = min(max(25, self.view_bars), max(25, n)) if n else 130
        self.update()
        self._emit_viewport()

    def set_basic_data(self, candles: list[dict], lines: dict | None = None, title: str = '', preserve_view: bool = False):
        lines = lines or {}
        series = {
            'candles': candles,
            'acc_flags': [False] * len(candles),
            'box': None,
            **lines,
        }
        self.set_data(None, series, title=title, preserve_view=preserve_view)

    def set_analysis_range(self, start_idx: int | None, end_idx: int | None):
        if start_idx is None or end_idx is None:
            self.analysis_range = None
        else:
            a, b = sorted((int(start_idx), int(end_idx)))
            self.analysis_range = (a, b)
        self.update()

    def clear_analysis_range(self):
        self.analysis_range = None
        self.update()

    def show_latest(self):
        if self.series:
            self.view_end = len(self.series.get('candles', []))
            self.update(); self._emit_viewport()

    def show_all(self):
        if self.series:
            n = len(self.series.get('candles', []))
            self.view_bars = max(25, n)
            self.view_end = n
            self.update(); self._emit_viewport()

    def pan_bars(self, bars: int):
        if not self.series:
            return
        total = len(self.series.get('candles', []))
        if total <= 0:
            return
        end = self.view_end if self.view_end is not None else total
        min_end = min(total, max(1, min(self.view_bars, total)))
        self.view_end = max(min_end, min(total, end + int(bars)))
        self.update(); self._emit_viewport()

    def zoom_by(self, factor: float):
        if not self.series:
            return
        total = len(self.series.get('candles', []))
        if total <= 0:
            return
        new_n = int(round(self.view_bars * factor))
        self.view_bars = max(25, min(total, new_n))
        if self.view_end is None:
            self.view_end = total
        self.view_end = max(min(self.view_bars, total), min(total, self.view_end))
        self.update(); self._emit_viewport()

    def visible_index_range(self) -> tuple[int, int]:
        if not self.series:
            return (0, 0)
        total = len(self.series.get('candles', []))
        end = self.view_end if self.view_end is not None else total
        end = max(1, min(total, end))
        start = max(0, end - min(self.view_bars, total))
        return start, end

    def visible_range_text(self) -> str:
        if not self.series or not self.series.get('candles'):
            return '-'
        start, end = self.visible_index_range()
        cs = self.series['candles']
        if end <= start:
            return '-'
        return f"{self._date_label(cs[start].get('date',''))} ~ {self._date_label(cs[end-1].get('date',''))} · {end-start}봉 / 전체 {len(cs)}봉"

    def _emit_viewport(self):
        self.viewportChanged.emit(self.visible_range_text())

    @staticmethod
    def _date_label(raw) -> str:
        s = ''.join(ch for ch in str(raw or '') if ch.isdigit())
        try:
            if len(s) >= 14:
                return datetime.strptime(s[:14], '%Y%m%d%H%M%S').strftime('%y/%m/%d %H:%M')
            if len(s) >= 8:
                return datetime.strptime(s[:8], '%Y%m%d').strftime('%y/%m/%d')
        except Exception:
            pass
        return str(raw or '-')[:10]

    def wheelEvent(self, event):
        if event.angleDelta().y() > 0:
            self.zoom_by(0.80)
        else:
            self.zoom_by(1.25)
        event.accept()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._drag_x = event.position().x()
            self._drag_end = self.view_end
            self.setCursor(Qt.ClosedHandCursor)
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._drag_x is not None and self.series:
            total = len(self.series.get('candles', []))
            width = max(1.0, self.width() - 80.0)
            px_per_bar = width / max(1, min(self.view_bars, total))
            delta = event.position().x() - self._drag_x
            shift = int(round(delta / max(1.0, px_per_bar)))
            # 오른쪽으로 끌면 과거, 왼쪽으로 끌면 최신 방향.
            end0 = self._drag_end if self._drag_end is not None else total
            min_end = min(total, max(1, min(self.view_bars, total)))
            self.view_end = max(min_end, min(total, end0 - shift))
            self.update(); self._emit_viewport()
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._drag_x = None
            self._drag_end = None
            self.unsetCursor()
        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event):
        self.show_latest()
        super().mouseDoubleClickEvent(event)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor('#091524'))
        if not self.series or not self.series.get('candles'):
            p.setPen(QColor('#8aa0b8'))
            p.drawText(self.rect(), Qt.AlignCenter, '데이터를 불러오면 차트가 표시됩니다.')
            return

        candles = self.series['candles']
        start, end = self.visible_index_range()
        cs = candles[start:end]
        n = len(cs)
        if n <= 0:
            return

        left, right, top = 60, 25, 28
        vol_h = 86
        watermelon_h = 34
        bottom = 42
        price_rect = QRectF(left, top, self.width()-left-right, self.height()-top-bottom-vol_h-watermelon_h)
        watermelon_rect = QRectF(left, price_rect.bottom()+3, price_rect.width(), watermelon_h)
        vol_rect = QRectF(left, watermelon_rect.bottom()+3, price_rect.width(), vol_h-10)

        total_candles = len(candles)
        future_count = int(self.series.get('future_count', 0) or 0) if end >= total_candles else 0
        display_n = max(1, n + future_count)

        vals = []
        for c in cs:
            vals += [c['high'], c['low']]
        line_keys = [k for k in self.series.keys() if k not in ('candles','acc_flags','acc_meta','box','watermelon','watermelon_stage','watermelon_score','watermelon_reason','watermelon_confirmed','watermelon_display','path_breakout','path_pullback','path_rebreakout','cloud_a','cloud_b','signal_pink','signal_blue','signal_red','signal_black','signal_sar','signal_bb40_22') and isinstance(self.series.get(k), list)]
        for key in line_keys:
            arr = self.series.get(key, [])
            vals += [v for v in arr[start:end] if isinstance(v, (int, float))]
        cloud_a = self.series.get('cloud_a', [])
        cloud_b = self.series.get('cloud_b', [])
        cloud_end = min(max(len(cloud_a), len(cloud_b)), end + future_count)
        if isinstance(cloud_a, list):
            vals += [v for v in cloud_a[start:cloud_end] if isinstance(v, (int, float))]
        if isinstance(cloud_b, list):
            vals += [v for v in cloud_b[start:cloud_end] if isinstance(v, (int, float))]
        lo, hi = min(vals), max(vals)
        pad = max((hi-lo)*0.08, hi*0.01, 1.0)
        lo -= pad; hi += pad

        def x(i): return price_rect.left() + (i + 0.5) * price_rect.width() / display_n
        def y(v): return price_rect.bottom() - (v-lo)/(hi-lo) * price_rect.height()

        # 선택 분석 구간 강조
        if self.analysis_range:
            a, b = self.analysis_range
            va = max(a, start); vb = min(b, end-1)
            if va <= vb:
                xs = x(va-start) - price_rect.width()/n/2
                xe = x(vb-start) + price_rect.width()/n/2
                p.fillRect(QRectF(xs, price_rect.top(), xe-xs, price_rect.height()+vol_h+watermelon_h), QColor(57,130,246,25))

        # 5분봉처럼 여러 거래일이 한 화면에 있을 때 날짜 경계를 명확히 분리.
        def day_key(raw):
            return ''.join(ch for ch in str(raw or '') if ch.isdigit())[:8]

        visible_days = [day_key(c.get('date', '')) for c in cs]
        unique_days = [d for i, d in enumerate(visible_days) if d and (i == 0 or d != visible_days[i-1])]
        # 일봉은 날짜 경계선을 그리지 않는다. 같은 거래일에 여러 봉이 존재하는 분봉에서만 표시.
        valid_days = [d for d in visible_days if d]
        is_intraday = len(valid_days) > len(set(valid_days))
        if is_intraday and len(unique_days) > 1:
            step_w = price_rect.width() / max(1, n)
            previous = visible_days[0] if visible_days else ''
            p.setFont(QFont('Malgun Gothic', 8, QFont.Bold))
            for i in range(1, n):
                current = visible_days[i]
                if current and current != previous:
                    xx = x(i) - step_w / 2
                    p.setPen(QPen(QColor('#5b7898'), 1, Qt.DashLine))
                    p.drawLine(QPointF(xx, price_rect.top()), QPointF(xx, vol_rect.bottom()))
                    label = f"{current[4:6]}/{current[6:8]}" if len(current) == 8 else current
                    p.setPen(QColor('#9bb8d1'))
                    p.drawText(int(xx + 4), int(price_rect.top() + 14), label)
                    previous = current

        # grid / y labels
        p.setPen(QPen(QColor('#17304a'), 1))
        for k in range(6):
            yy = price_rect.top() + k*price_rect.height()/5
            p.drawLine(QPointF(price_rect.left(), yy), QPointF(price_rect.right(), yy))
            value = hi - k*(hi-lo)/5
            p.setPen(QColor('#7f93a9')); p.drawText(5, int(yy+4), f'{value:,.0f}'); p.setPen(QPen(QColor('#17304a'),1))

        # 일목균형표 선행스팬 1·2: 사용자 영웅문 화면처럼 파란 구름대로 표시.
        # 최신 구간에서는 표준 +26 선행 구간까지 오른쪽에 예약해 구름이 앞쪽으로 이어진다.
        if isinstance(cloud_a, list) and isinstance(cloud_b, list):
            pts_a = []
            pts_b = []
            cloud_last = min(len(cloud_a), len(cloud_b), end + future_count)
            for gi in range(start, cloud_last):
                a = cloud_a[gi]
                b = cloud_b[gi]
                if not isinstance(a, (int, float)) or not isinstance(b, (int, float)):
                    continue
                xx = x(gi - start)
                pts_a.append(QPointF(xx, y(a)))
                pts_b.append(QPointF(xx, y(b)))
            if len(pts_a) >= 2 and len(pts_b) >= 2:
                poly = QPolygonF(pts_a + list(reversed(pts_b)))
                p.setPen(Qt.NoPen)
                p.setBrush(QColor(40, 92, 255, 120))
                p.drawPolygon(poly)
                p.setBrush(Qt.NoBrush)
                p.setPen(QPen(QColor('#1f55ff'), 1.2))
                for pts in (pts_a, pts_b):
                    for j in range(1, len(pts)):
                        p.drawLine(pts[j-1], pts[j])

        # 공구리/전고점언덕: 구조 종류를 구분해서 표시.
        box = self.series.get('box')
        if box and box.get('start',-1) < end and box.get('end',-1) >= start:
            bs = max(start, box['start']); be = min(end-1, box['end'])
            xs = x(bs-start)-4; xe = x(be-start)+4
            structure_type = str(box.get('structure_type') or '공구리')

            if structure_type == '공구리':
                r = QRectF(xs, y(box['high']), xe-xs, y(box['low'])-y(box['high']))
                p.setPen(QPen(QColor('#f4ce48'),2,Qt.DashLine))
                p.setBrush(QColor(244,206,72,24))
                p.drawRect(r)
                p.setPen(QColor('#f4ce48'))
                p.drawText(
                    int(xs+6), int(y(box['high'])-6),
                    f"공구리 · 지지/저항 {box.get('period','-')}봉"
                )
            else:
                p.setPen(QPen(QColor('#f4ce48'),2,Qt.DashLine))
                p.drawLine(QPointF(xs, y(box['high'])), QPointF(xe, y(box['high'])))
                p.drawText(int(xs+6), int(y(box['high'])-6), '전고점언덕 저항')

            if box.get('breakout_idx', -1) >= 0:
                p.setPen(QPen(QColor('#f4ce48'), 1.6, Qt.DashLine))
                p.drawLine(QPointF(xe, y(box['high'])), QPointF(price_rect.right(), y(box['high'])))
                p.drawText(int(min(price_rect.right()-85, xe+6)), int(y(box['high'])-7), '돌파기준선')

        maxvol = max(c['volume'] for c in cs) or 1
        p.setPen(QColor('#91a8bd'))
        p.setFont(QFont('Malgun Gothic', 8, QFont.Bold))
        p.drawText(int(vol_rect.left()+4), int(vol_rect.top()+12), '거래량  ↑빨강 / ↓파랑')
        p.setPen(QPen(QColor('#263d58'), 1))
        p.drawLine(QPointF(vol_rect.left(), vol_rect.top()), QPointF(vol_rect.right(), vol_rect.top()))

        acc_full = self.series.get('acc_flags', [False]*len(candles))
        acc = acc_full[start:end] if len(acc_full) >= end else [False]*n
        cw = max(1.5, min(12.0, price_rect.width()/n*0.58))
        for i,c in enumerate(cs):
            xx=x(i)

            # 캔들 색: 가격 상승=빨강, 하락=파랑
            up=c['close']>=c['open']
            candle_col=QColor('#ef4747') if up else QColor('#2d77ff')

            if i < len(acc) and acc[i]:
                p.fillRect(QRectF(xx-cw*0.9, price_rect.top(), cw*1.8, price_rect.height()), QColor(255,190,35,25))
                if n <= 180:
                    p.setPen(QColor('#ffc13d')); p.drawText(int(xx-26), int(price_rect.top()+18), '매집확정')

            p.setPen(QPen(candle_col,1.1))
            p.drawLine(QPointF(xx,y(c['low'])),QPointF(xx,y(c['high'])))
            yo,yc=y(c['open']),y(c['close'])
            r=QRectF(xx-cw/2,min(yo,yc),cw,max(1.2,abs(yc-yo)))
            p.fillRect(r,candle_col)

            # 거래량 색은 캔들 등락과 무관하게 직전 봉 대비 거래량 증감 기준.
            # 증가=빨강 / 감소=파랑 / 동일=회색.
            global_i = start + i
            prev_vol = candles[global_i-1]['volume'] if global_i > 0 else c['volume']
            if c['volume'] > prev_vol:
                volume_col = QColor('#ef4747')
            elif c['volume'] < prev_vol:
                volume_col = QColor('#2d77ff')
            else:
                volume_col = QColor('#7f93a9')

            vh=vol_rect.height()*c['volume']/maxvol
            p.fillRect(
                QRectF(xx-cw/2,vol_rect.bottom()-vh,cw,vh),
                QColor(volume_col.red(),volume_col.green(),volume_col.blue(),185)
            )

            gi = start + i
            path_break = self.series.get('path_breakout', [])
            path_pull = self.series.get('path_pullback', [])
            path_rebreak = self.series.get('path_rebreakout', [])
            label = ''
            label_color = QColor('#ffffff')
            if isinstance(path_rebreak, list) and gi < len(path_rebreak) and path_rebreak[gi]:
                label = '✓재돌파'; label_color = QColor('#ffcf3d')
            elif isinstance(path_pull, list) and gi < len(path_pull) and path_pull[gi]:
                label = '✓눌림'; label_color = QColor('#62d98b')
            elif isinstance(path_break, list) and gi < len(path_break) and path_break[gi]:
                label = '✓돌파'; label_color = QColor('#ff6a6a')
            if label:
                p.setPen(label_color)
                p.setFont(QFont('Malgun Gothic', 8, QFont.Bold))
                p.drawText(int(xx-16), int(max(price_rect.top()+32, y(c['high'])-8)), label)

        # PUMA 수박근사: 확정구간만 표시.
        # stage 1/2 후보는 화면에 그리지 않고, strict 조건을 모두 통과한 이벤트만
        # 20봉 cooldown을 거쳐 큰 수박 한 개로 표시한다.
        wm = self.series.get('watermelon_display', [])
        if isinstance(wm, list) and wm:
            # 수박 이름 텍스트는 숨기고 모양만 표시.
            for i, stage in enumerate(wm[start:end]):
                if not stage:
                    continue
                xx = x(i)
                cy = watermelon_rect.center().y()
                radius = 13.0

                p.setPen(QPen(QColor('#ffd44a'), 2.5))
                p.setBrush(Qt.NoBrush)
                p.drawEllipse(QPointF(xx, cy), radius+3.5, radius+3.5)

                p.setPen(QPen(QColor('#08753a'), 2.2))
                p.setBrush(QColor('#35b85c'))
                p.drawEllipse(QPointF(xx, cy), radius, radius)

                p.setPen(Qt.NoPen)
                p.setBrush(QColor('#ef4c5b'))
                p.drawEllipse(QPointF(xx, cy), radius-3.2, radius-3.2)

                p.setBrush(QColor('#1c1515'))
                for dx, dy in ((-4,-3),(0,-4),(4,-3),(-2,3),(3,3)):
                    p.drawEllipse(QPointF(xx+dx, cy+dy), 1.0, 1.6)
                p.setBrush(Qt.NoBrush)

        # 사용자 영웅문 화살표 4종.
        # 같은 봉에 여러 신호가 겹쳐도 4개가 서로 가리지 않도록 전용 lane을 사용.
        # 검정 화살표는 PUMA의 검정 배경에서도 보이도록 흰 외곽선을 가장 강하게 적용.
        sig_defs = [
            ('signal_pink',  QColor('#ff2fcf'), 0),
            ('signal_blue',  QColor('#1e5bff'), 1),
            ('signal_red',   QColor('#ff3038'), 2),
            ('signal_black', QColor('#050505'), 3),
        ]
        for key, sig_color, lane in sig_defs:
            arr = self.series.get(key, [])
            if not isinstance(arr, list):
                continue
            visible = arr[start:end]
            for i, active in enumerate(visible):
                if not active:
                    continue

                xx = x(i)
                lane_gap = 13.0
                base = min(
                    price_rect.bottom() - 4,
                    y(cs[i]['low']) + 14 + lane * lane_gap
                )
                apex = base - 12

                # 밝은 halo: 배경/캔들/이평선 위에서도 신호 형태가 유지된다.
                halo = QColor('#ffffff')
                outer = QPolygonF([
                    QPointF(xx, apex - 3),
                    QPointF(xx - 9, apex + 10),
                    QPointF(xx + 9, apex + 10),
                ])
                p.setPen(QPen(halo, 2.8))
                p.setBrush(halo)
                p.drawPolygon(outer)
                p.drawLine(QPointF(xx, base + 9), QPointF(xx, apex + 4))

                inner = QPolygonF([
                    QPointF(xx, apex),
                    QPointF(xx - 6, apex + 8),
                    QPointF(xx + 6, apex + 8),
                ])
                p.setPen(QPen(sig_color, 2.0))
                p.setBrush(sig_color)
                p.drawPolygon(inner)
                p.drawLine(QPointF(xx, base + 7), QPointF(xx, apex + 4))

                # 검정색은 중앙에 얇은 흰 점을 한 번 더 넣어 검정 fill도 식별 가능하게 한다.
                if key == 'signal_black':
                    p.setPen(QPen(QColor('#ffffff'), 1.4))
                    p.setBrush(QColor('#ffffff'))
                    p.drawEllipse(QPointF(xx, apex + 5), 1.8, 1.8)

                p.setBrush(Qt.NoBrush)

        # 사용자 영웅문 화면의 시각 체계를 PUMA 어두운 배경에 맞게 재현.
        # 5=노랑, 20=빨강, 60=초록, 112=갈색/주황, 224=검정 굵게, 448=회색 점선.
        colors={
            'ema5':'#ffd21f',
            'ema20':'#ff3434',
            'ema60':'#00b85a',
            'ema112':'#b85a18',
            'ema224':'#050505',
            'ema448':'#9aa0a6',
            'blue':'#1f49ff',
            'kijun':'#f2e7a3'
        }
        widths={
            'ema5':2.3,'ema20':2.1,'ema60':2.1,'ema112':2.5,
            'ema224':3.2,'ema448':1.8,'blue':3.2,'kijun':5.0
        }
        styles={'blue':Qt.DotLine,'ema448':Qt.DashLine}
        priority = ['ema448','ema224','ema112','ema60','ema20','ema5','blue','kijun']
        ordered = [k for k in priority if k in line_keys] + [k for k in line_keys if k not in priority]
        for key in ordered:
            col = QColor(colors.get(key, '#9bb8d1'))
            if key == 'ema224':
                # 영웅문에서는 회색 배경이라 검정 224선이 잘 보인다.
                # PUMA 검정 배경에서는 밝은 외곽선을 먼저 깔고 검정 코어를 그린다.
                self._draw_series(p, self.series[key], start, end, x, y, QColor('#d9dde3'), 5.0, Qt.SolidLine)
            if key == 'kijun':
                self._draw_series(p, self.series[key], start, end, x, y, QColor('#b71c1c'), 1.0, Qt.SolidLine)
            self._draw_series(p, self.series[key], start, end, x, y, col, widths.get(key,1.5), styles.get(key,Qt.SolidLine))

        # breakout marker
        bi = getattr(self.analysis, 'breakout_index', -1) if self.analysis is not None else -1
        if start <= bi < end:
            xx=x(bi-start); p.setPen(QPen(QColor('#61ff8f'),2)); p.drawLine(QPointF(xx,price_rect.top()+18),QPointF(xx,price_rect.bottom()))
            p.setPen(QColor('#61ff8f')); p.setFont(QFont('Malgun Gothic',9,QFont.Bold)); p.drawText(int(xx+5), int(price_rect.top()+34), '박스 상단 돌파')

        # x-axis 날짜 라벨
        p.setPen(QColor('#8298af')); p.setFont(QFont('Malgun Gothic',8))
        ticks = min(6, n)
        for k in range(ticks):
            j = int(round(k*(n-1)/max(1,ticks-1)))
            txt = self._date_label(cs[j].get('date',''))
            p.drawText(int(x(j)-35), int(vol_rect.bottom()+7), 75, 18, Qt.AlignCenter, txt)

        # 차트 상단은 종목/봉 정보만 남긴다.
        # EMA/기준선/파란점선/일목/수박 등 지표 이름 범례는 차트 위를 가리지 않도록 숨김.
        p.setPen(QColor('#d7e8f7'))
        p.setFont(QFont('Malgun Gothic',10,QFont.Bold))
        if self.title:
            p.drawText(int(price_rect.left()), 19, self.title)

        p.setPen(QColor('#7991aa'))
        p.setFont(QFont('Malgun Gothic',8))
        p.drawText(
            int(price_rect.right()-410), 19, 400, 18, Qt.AlignRight,
            '휠: 확대/축소 · 드래그: 과거/최신 이동 · 더블클릭: 최신'
        )

    def _draw_series(self,p,arr,start,end,x,y,color,width,style):
        p.setPen(QPen(color,width,style)); prev=None
        for idx in range(start, end):
            if idx<0 or idx>=len(arr) or arr[idx] is None:
                prev=None; continue
            pt=QPointF(x(idx-start),y(arr[idx]))
            if prev is not None: p.drawLine(prev,pt)
            prev=pt
